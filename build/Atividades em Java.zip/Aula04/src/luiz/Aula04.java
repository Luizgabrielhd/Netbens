/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package luiz;
import java.util.Date;
import java.util.Locale;
import java.awt.Toolkit;
import java.awt.Dimension;

/**
 *
 * @author lgmrt
 */
public class Aula04 {

    public static void main(String[] args) {
        System.out.println("Ola mundo Java!!!");
        Date relogio = new Date();
        System.out.println("A hora do sistema e:");
        System.out.println(relogio.toString());
        
        Locale loc = Locale.getDefault();
        System.out.print("O idioma do seu sistema e: ");
        System.out.println(loc.getDisplayLanguage()); 

        Toolkit tk = Toolkit.getDefaultToolkit();
        Dimension d = tk.getScreenSize();
        System.out.print("A resolução da sua tela e: ");
        System.out.println(d.width + " x " + d.height);
        
    
    }
    
}
