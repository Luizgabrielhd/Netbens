/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula12;

import javax.swing.JOptionPane;

/**
 *
 * @author lgmrt
 */
public class Aula12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int n;
        int totalValores = 0;
        int totalPares = 0;
        int totalImpares = 0;
        int acimaCem = 0;
        int soma = 0;
        do {
            n = Integer.parseInt(JOptionPane.showInputDialog(null,
                    "<html>Informe um número:<br><em>(valor 0 interrompe)</em></html>"));

            if (n != 0) {
                soma += n;
                totalValores++;

                if (n % 2 == 0) {
                    totalPares++;
                } else {
                    totalImpares++;
                }

                if (n > 100) {
                    acimaCem++;
                }
            }

        } while (n != 0);

       int media;
       if (totalValores > 0) {
        media = soma / totalValores;
        } else {
        media = 0;
    }

       
        JOptionPane.showMessageDialog(null, 
                "<html>Resultado:<hr>" +
                "<br>Total de Valores: " + totalValores +
                "<br>Total de Pares: " + totalPares +
                "<br>Total de Ímpares: " + totalImpares +
                "<br>Acima de 100: " + acimaCem +
                "<br>Média dos valores: " + media + "</html>", 
                "Resultado Final", JOptionPane.WARNING_MESSAGE);
        
      
   }
}
