
package aula17;
public class Aula17 {      
    public static void main(String[] args) {
        Caneta c1 = new Caneta("Nic",0.4f, "Amarelo");
        c1.status();
        Caneta c2 = new Caneta("KKK",0.5f,"Verde");
        c2.status();
        
    }
    
}
