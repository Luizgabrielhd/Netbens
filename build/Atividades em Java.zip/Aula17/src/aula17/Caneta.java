
package aula17;
public class Caneta {
    private String modelo;
    private float ponta;
    private boolean tampada;
    private boolean destampar;
    private String cor;
    
    public Caneta(String modelo, float ponta, String cor) {
        this.modelo = modelo;
        this.ponta = ponta;
        this.cor = cor;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public float getPonta() {
        return ponta;
    }

    public void setPonta(float ponta) {
        this.ponta = ponta;
    }

    public boolean isTampada() {
        return tampada;
    }

    public void setTampada(boolean tampada) {
        this.tampada = tampada;
    }

    public boolean isDestampar() {
        return destampar;
    }

    public void setDestampar(boolean destampar) {
        this.destampar = destampar;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }
     public void status(){
        System.out.println("Sobre a caneta:");
        System.out.println("Modelo: "+ this.getModelo());
        System.out.println("Ponta:  "+this.getPonta());
        System.out.println("Cor:    "+this.cor);
        System.out.println("Tampada: "+this.tampada);
             
    }
}
    
