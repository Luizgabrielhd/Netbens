package aula19;
public class Aula19 {
    public static void main(String[] args) {
        ControleRemoto c = new ControleRemoto();
        c.maisVolume();
        c.play();
        c.abrirMenu();
        c.fecharMenu();
        
       
    }
    
}
