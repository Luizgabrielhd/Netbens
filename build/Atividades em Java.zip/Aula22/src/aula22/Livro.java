package aula22;
public class Livro implements Publicacao{
    private String titulo;
    private String autor;
    private int totPaginas;
    private int pagAtual;
    private boolean aberto;
    private Pessoa leitor;

    
    public String detalhes() {
        return "Livro:"
                + "\n Titulo: " + titulo
                + "\n Autor: " + autor
                + "\n TotPaginas: " + totPaginas
                + "\n PagAtual: " + pagAtual
                + "\n Aberto: " + aberto
                + "\n Leitor:" + leitor.getNome() 
                + "\n Idade:" + leitor.getIdade()
                + "\n Sexo:" + leitor.getSexo();
        
    }
    

    public Livro(String titulo, String autor, int totPaginas, Pessoa leitor) {
        this.titulo = titulo;
        this.autor = autor;
         this.pagAtual = 0;
        this.aberto = false;
        this.totPaginas = totPaginas;
        this.leitor = leitor;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getTotPaginas() {
        return totPaginas;
    }

    public void setPagAtual(int pagAtual) {
        this.pagAtual = pagAtual;
    }

    public int getPagAtual() {
        return pagAtual;
    }

    public void setTotPaginas(int totPaginas) {
        this.totPaginas = totPaginas;
    }

    public boolean isAberto() {
        return aberto;
    }

    public void setAberto(boolean aberto) {
        this.aberto = aberto;
    }

    public Pessoa getLeitor() {
        return leitor;
    }

    public void setLeitor(Pessoa leitor) {
        this.leitor = leitor;
    }

   
    @Override
    public void abrir() {
        aberto = true;
    }
     @Override
    public void fechar() {
          aberto = false;
        pagAtual = 0; 
    }
 @Override
public void folhear(int p) {
    if (p > this.totPaginas) {
        this.pagAtual = 0;
    } else {
        this.pagAtual = p;
    }
}
     @Override
    public void avancarPag() {
        if (aberto) {
            pagAtual += pagAtual < totPaginas ? 1 : 0;
        }
    }
     @Override
    public void voltarPag() {
       if (aberto) {
            pagAtual -= pagAtual > 0 ? 1 : 0;
        }
        
    } 

    
}
