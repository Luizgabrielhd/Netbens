package aula25;

public class Aula25 {
    public static void main(String[] args) {
        
        
        Mamifero m = new Mamifero();
        Reptil r = new Reptil();
        Peixe p = new Peixe();
        Ave a = new Ave();
        
        Canguru c = new Canguru();
        Cachorro k = new Cachorro();
        Cobra j = new Cobra();
        Tartaruga t = new Tartaruga();
        Goldfish g = new Goldfish();
        Arara e = new Arara();
        
        System.out.println("--- Mamífero ---");
        m.setPeso(35.3f);
        m.setCorPelo("Marrom");
        m.alimentar();
        m.locomover();
        m.emitirSom();
        
        System.out.println("\n--- Locomoção ---");
        a.locomover(); 
        p.locomover(); 
        r.locomover(); 
        
        System.out.println("\n--- Canguru x Cachorro ---");
        c.locomover(); 
        k.locomover(); 
        
        c.emitirSom(); 
        k.emitirSom(); 
    }
}