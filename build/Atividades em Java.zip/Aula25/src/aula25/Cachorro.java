package aula25;

public class Cachorro extends Mamifero {
    @Override
    public void emitirSom() {
        System.out.println("Au! Au! Au!");
    }
}   