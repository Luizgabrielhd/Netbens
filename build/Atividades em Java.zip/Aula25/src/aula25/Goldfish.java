package aula25;
public class Goldfish extends Peixe { } 