package aula26;

public class Aula26 {
    public static void main(String[] args) {
        
        Cachorro c = new Cachorro();
        
        System.out.println("--- Teste 1 ---");
        c.reagir("Olá");
        c.reagir("Vai apanhar");
        
        System.out.println("\n--- Teste 2 ---");
        c.reagir(11, 45);
        c.reagir(19, 00);
        
        System.out.println("\n--- Teste 3 ---");
        c.reagir(true);
        c.reagir(false);
        
        System.out.println("\n--- Teste 4 ---");    
        c.reagir(2, 12.5f);
        c.reagir(17, 4.5f);
    }
}