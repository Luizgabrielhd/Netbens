package sistemavendamedicamentos;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Farmacia {
    private List<Medicamento> medicamentos;

    public Farmacia() {
        this.medicamentos = new ArrayList<>();
    }

    public void adicionarMedicamento(Medicamento m) {
        this.medicamentos.add(m);
    }

    public double calcularTotalSemDesconto() {
        double total = 0;
        for (int i = 0; i < medicamentos.size(); i++) {
            total += medicamentos.get(i).getValor();
        }
        return total;
    }

    public double calcularTotalComDesconto() {
        double total = 0;
        for (int i = 0; i < medicamentos.size(); i++) {
            total += medicamentos.get(i).getValorComDesconto();
        }
        return total;
    }

    public void imprimirResumoVenda() {
        
        Locale ptBR = new Locale("pt", "BR");
        
        System.out.println("***** RESUMO DA VENDA *****");
        
        for (int i = 0; i < medicamentos.size(); i++) {
            Medicamento m = medicamentos.get(i);
            
            System.out.printf(ptBR, "%s - R$ %.2f -> R$ %.2f\n", 
                              m.getDescricao(), m.getValor(), m.getValorComDesconto());
        }
        
        System.out.println("***************************");
        System.out.printf(ptBR, "VALOR TOTAL SEM DESCONTO: R$ %.2f\n", calcularTotalSemDesconto());
        System.out.printf(ptBR, "VALOR TOTAL COM DESCONTO: R$ %.2f\n", calcularTotalComDesconto());
        System.out.println("***************************");
    }
}