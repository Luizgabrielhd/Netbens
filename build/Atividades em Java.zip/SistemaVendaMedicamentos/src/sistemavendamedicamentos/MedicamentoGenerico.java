package sistemavendamedicamentos;

public class MedicamentoGenerico extends Medicamento {

    public MedicamentoGenerico(String nome, double valor) {
        super(nome, valor);
    }

    @Override
    public double getValorComDesconto() {
        return this.getValor() * 0.80; 
    }

    @Override
    public String getDescricao() {
        return this.getNome();
    }
}