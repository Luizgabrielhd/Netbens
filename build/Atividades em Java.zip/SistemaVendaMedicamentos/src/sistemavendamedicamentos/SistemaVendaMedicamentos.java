package sistemavendamedicamentos;

public class SistemaVendaMedicamentos {
    public static void main(String[] args) {
        Farmacia farmacia = new Farmacia();

        
        farmacia.adicionarMedicamento(new MedicamentoGenerico("Paracetamol", 10.00));
        farmacia.adicionarMedicamento(new MedicamentoGenerico("Ibuprofeno", 15.00));
        farmacia.adicionarMedicamento(new MedicamentoGenerico("Dipirona", 8.00));

        
        farmacia.adicionarMedicamento(new MedicamentoMarca("Aspirina", 20.00, "Bayer"));
        farmacia.adicionarMedicamento(new MedicamentoMarca("Allegra", 35.00, "Sanofi"));

        
        farmacia.imprimirResumoVenda();
    }
}